#include "frontend.h"

const char* Transaction::codeNames[] = {"CR","DL","DE","WD","TR","ES"};

